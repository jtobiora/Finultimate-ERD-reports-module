
package com.s3systems.remote.sales;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.s3systems.remote.sales package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetClientRecordListResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getClientRecordListResponse");
    private final static QName _ClientRecordNotFoundException_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "ClientRecordNotFoundException");
    private final static QName _GetAllSessionResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllSessionResponse");
    private final static QName _FindStockItemByIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "findStockItemByIDResponse");
    private final static QName _GetWarehouseList_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getWarehouseList");
    private final static QName _ReloadResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "reloadResponse");
    private final static QName _GetDocumentsByRefResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentsByRefResponse");
    private final static QName _GetStockItemListByActiveIngredientID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByActiveIngredientID");
    private final static QName _GetAllPromotionsResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllPromotionsResponse");
    private final static QName _GetStockItemListResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListResponse");
    private final static QName _CreateSalesOrderResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "createSalesOrderResponse");
    private final static QName _Validate_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "validate");
    private final static QName _GetAllWarehouseListByUserDepartmentIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllWarehouseListByUserDepartmentIDResponse");
    private final static QName _SaveReceipt_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveReceipt");
    private final static QName _GetAllSession_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllSession");
    private final static QName _GetWarehouseListResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getWarehouseListResponse");
    private final static QName _LoginUser_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "loginUser");
    private final static QName _Reload_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "reload");
    private final static QName _SaveDocumentsResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveDocumentsResponse");
    private final static QName _SaveSettings_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveSettings");
    private final static QName _Exception_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "Exception");
    private final static QName _GetStockItemCategoryList_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemCategoryList");
    private final static QName _GetDocumentsByRef_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentsByRef");
    private final static QName _GetStockItemListByWareHouse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByWareHouse");
    private final static QName _SaveReceiptResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveReceiptResponse");
    private final static QName _FindStockRelationListByIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "findStockRelationListByIDResponse");
    private final static QName _GetStockItemListByCategoryResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByCategoryResponse");
    private final static QName _GetStockItemListByItemTypeIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByItemTypeIDResponse");
    private final static QName _GetAllBanks_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllBanks");
    private final static QName _UploadReceiptResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "uploadReceiptResponse");
    private final static QName _ValidateResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "validateResponse");
    private final static QName _CreateSalesOrder_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "createSalesOrder");
    private final static QName _GetAllDocuments_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllDocuments");
    private final static QName _GetAllWarehouseListByUserDepartmentID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllWarehouseListByUserDepartmentID");
    private final static QName _GetStockItemListByWareHouseResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByWareHouseResponse");
    private final static QName _GetRelatedStockItemListByIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getRelatedStockItemListByIDResponse");
    private final static QName _GetSystemSettings_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getSystemSettings");
    private final static QName _GetSystemSettingsResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getSystemSettingsResponse");
    private final static QName _StartSessionResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "startSessionResponse");
    private final static QName _GetAllPromotions_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllPromotions");
    private final static QName _GetDocumentByID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentByID");
    private final static QName _GetStockItemListByItemTypeID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByItemTypeID");
    private final static QName _GetDocumentByName_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentByName");
    private final static QName _UploadReceipt_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "uploadReceipt");
    private final static QName _CreateReceipt_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "createReceipt");
    private final static QName _GetAllBanksResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllBanksResponse");
    private final static QName _GetDocumentsBySource_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentsBySource");
    private final static QName _FindStockItemByID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "findStockItemByID");
    private final static QName _ValidateUser_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "validateUser");
    private final static QName _GetActivePromotionListResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getActivePromotionListResponse");
    private final static QName _GetAllWarehouseListByUserBranchIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllWarehouseListByUserBranchIDResponse");
    private final static QName _UploadSession_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "uploadSession");
    private final static QName _StopSession_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "stopSession");
    private final static QName _ValidateUserResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "validateUserResponse");
    private final static QName _GetStockItemListByActiveIngredientIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByActiveIngredientIDResponse");
    private final static QName _LoginUserResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "loginUserResponse");
    private final static QName _SaveDocuments_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveDocuments");
    private final static QName _GetAllWarehouseListByUserBranchID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllWarehouseListByUserBranchID");
    private final static QName _GetDocumentByNameResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentByNameResponse");
    private final static QName _SaveSettingsResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveSettingsResponse");
    private final static QName _StopSessionResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "stopSessionResponse");
    private final static QName _StartSession_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "startSession");
    private final static QName _GetDocumentByIDResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentByIDResponse");
    private final static QName _GetRelatedStockItemListByID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getRelatedStockItemListByID");
    private final static QName _GetStockItemListByCategory_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemListByCategory");
    private final static QName _SaveDocumentResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveDocumentResponse");
    private final static QName _GetActivePromotionList_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getActivePromotionList");
    private final static QName _UploadSessionResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "uploadSessionResponse");
    private final static QName _GetDocumentsBySourceResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getDocumentsBySourceResponse");
    private final static QName _GetStockItemCategoryListResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemCategoryListResponse");
    private final static QName _GetClientRecordList_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getClientRecordList");
    private final static QName _SaveDocument_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "saveDocument");
    private final static QName _GetStockItemList_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getStockItemList");
    private final static QName _CreateReceiptResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "createReceiptResponse");
    private final static QName _GetAllDocumentsResponse_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "getAllDocumentsResponse");
    private final static QName _FindStockRelationListByID_QNAME = new QName("http://services.endpoint.business.rsdynamix.com/", "findStockRelationListByID");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.s3systems.remote.sales
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetStockItemListByActiveIngredientIDResponse }
     * 
     */
    public GetStockItemListByActiveIngredientIDResponse createGetStockItemListByActiveIngredientIDResponse() {
        return new GetStockItemListByActiveIngredientIDResponse();
    }

    /**
     * Create an instance of {@link LoginUserResponse }
     * 
     */
    public LoginUserResponse createLoginUserResponse() {
        return new LoginUserResponse();
    }

    /**
     * Create an instance of {@link SaveDocuments }
     * 
     */
    public SaveDocuments createSaveDocuments() {
        return new SaveDocuments();
    }

    /**
     * Create an instance of {@link GetAllWarehouseListByUserBranchID }
     * 
     */
    public GetAllWarehouseListByUserBranchID createGetAllWarehouseListByUserBranchID() {
        return new GetAllWarehouseListByUserBranchID();
    }

    /**
     * Create an instance of {@link StopSession }
     * 
     */
    public StopSession createStopSession() {
        return new StopSession();
    }

    /**
     * Create an instance of {@link ValidateUserResponse }
     * 
     */
    public ValidateUserResponse createValidateUserResponse() {
        return new ValidateUserResponse();
    }

    /**
     * Create an instance of {@link GetActivePromotionListResponse }
     * 
     */
    public GetActivePromotionListResponse createGetActivePromotionListResponse() {
        return new GetActivePromotionListResponse();
    }

    /**
     * Create an instance of {@link GetAllWarehouseListByUserBranchIDResponse }
     * 
     */
    public GetAllWarehouseListByUserBranchIDResponse createGetAllWarehouseListByUserBranchIDResponse() {
        return new GetAllWarehouseListByUserBranchIDResponse();
    }

    /**
     * Create an instance of {@link UploadSession }
     * 
     */
    public UploadSession createUploadSession() {
        return new UploadSession();
    }

    /**
     * Create an instance of {@link GetActivePromotionList }
     * 
     */
    public GetActivePromotionList createGetActivePromotionList() {
        return new GetActivePromotionList();
    }

    /**
     * Create an instance of {@link GetStockItemListByCategory }
     * 
     */
    public GetStockItemListByCategory createGetStockItemListByCategory() {
        return new GetStockItemListByCategory();
    }

    /**
     * Create an instance of {@link SaveDocumentResponse }
     * 
     */
    public SaveDocumentResponse createSaveDocumentResponse() {
        return new SaveDocumentResponse();
    }

    /**
     * Create an instance of {@link StartSession }
     * 
     */
    public StartSession createStartSession() {
        return new StartSession();
    }

    /**
     * Create an instance of {@link GetDocumentByIDResponse }
     * 
     */
    public GetDocumentByIDResponse createGetDocumentByIDResponse() {
        return new GetDocumentByIDResponse();
    }

    /**
     * Create an instance of {@link GetRelatedStockItemListByID }
     * 
     */
    public GetRelatedStockItemListByID createGetRelatedStockItemListByID() {
        return new GetRelatedStockItemListByID();
    }

    /**
     * Create an instance of {@link GetDocumentByNameResponse }
     * 
     */
    public GetDocumentByNameResponse createGetDocumentByNameResponse() {
        return new GetDocumentByNameResponse();
    }

    /**
     * Create an instance of {@link SaveSettingsResponse }
     * 
     */
    public SaveSettingsResponse createSaveSettingsResponse() {
        return new SaveSettingsResponse();
    }

    /**
     * Create an instance of {@link StopSessionResponse }
     * 
     */
    public StopSessionResponse createStopSessionResponse() {
        return new StopSessionResponse();
    }

    /**
     * Create an instance of {@link GetStockItemCategoryListResponse }
     * 
     */
    public GetStockItemCategoryListResponse createGetStockItemCategoryListResponse() {
        return new GetStockItemCategoryListResponse();
    }

    /**
     * Create an instance of {@link GetDocumentsBySourceResponse }
     * 
     */
    public GetDocumentsBySourceResponse createGetDocumentsBySourceResponse() {
        return new GetDocumentsBySourceResponse();
    }

    /**
     * Create an instance of {@link UploadSessionResponse }
     * 
     */
    public UploadSessionResponse createUploadSessionResponse() {
        return new UploadSessionResponse();
    }

    /**
     * Create an instance of {@link FindStockRelationListByID }
     * 
     */
    public FindStockRelationListByID createFindStockRelationListByID() {
        return new FindStockRelationListByID();
    }

    /**
     * Create an instance of {@link CreateReceiptResponse }
     * 
     */
    public CreateReceiptResponse createCreateReceiptResponse() {
        return new CreateReceiptResponse();
    }

    /**
     * Create an instance of {@link GetAllDocumentsResponse }
     * 
     */
    public GetAllDocumentsResponse createGetAllDocumentsResponse() {
        return new GetAllDocumentsResponse();
    }

    /**
     * Create an instance of {@link GetStockItemList }
     * 
     */
    public GetStockItemList createGetStockItemList() {
        return new GetStockItemList();
    }

    /**
     * Create an instance of {@link GetClientRecordList }
     * 
     */
    public GetClientRecordList createGetClientRecordList() {
        return new GetClientRecordList();
    }

    /**
     * Create an instance of {@link SaveDocument }
     * 
     */
    public SaveDocument createSaveDocument() {
        return new SaveDocument();
    }

    /**
     * Create an instance of {@link GetAllPromotionsResponse }
     * 
     */
    public GetAllPromotionsResponse createGetAllPromotionsResponse() {
        return new GetAllPromotionsResponse();
    }

    /**
     * Create an instance of {@link GetDocumentsByRefResponse }
     * 
     */
    public GetDocumentsByRefResponse createGetDocumentsByRefResponse() {
        return new GetDocumentsByRefResponse();
    }

    /**
     * Create an instance of {@link GetStockItemListByActiveIngredientID }
     * 
     */
    public GetStockItemListByActiveIngredientID createGetStockItemListByActiveIngredientID() {
        return new GetStockItemListByActiveIngredientID();
    }

    /**
     * Create an instance of {@link FindStockItemByIDResponse }
     * 
     */
    public FindStockItemByIDResponse createFindStockItemByIDResponse() {
        return new FindStockItemByIDResponse();
    }

    /**
     * Create an instance of {@link GetWarehouseList }
     * 
     */
    public GetWarehouseList createGetWarehouseList() {
        return new GetWarehouseList();
    }

    /**
     * Create an instance of {@link ReloadResponse }
     * 
     */
    public ReloadResponse createReloadResponse() {
        return new ReloadResponse();
    }

    /**
     * Create an instance of {@link GetClientRecordListResponse }
     * 
     */
    public GetClientRecordListResponse createGetClientRecordListResponse() {
        return new GetClientRecordListResponse();
    }

    /**
     * Create an instance of {@link ClientRecordNotFoundException }
     * 
     */
    public ClientRecordNotFoundException createClientRecordNotFoundException() {
        return new ClientRecordNotFoundException();
    }

    /**
     * Create an instance of {@link GetAllSessionResponse }
     * 
     */
    public GetAllSessionResponse createGetAllSessionResponse() {
        return new GetAllSessionResponse();
    }

    /**
     * Create an instance of {@link GetAllSession }
     * 
     */
    public GetAllSession createGetAllSession() {
        return new GetAllSession();
    }

    /**
     * Create an instance of {@link GetWarehouseListResponse }
     * 
     */
    public GetWarehouseListResponse createGetWarehouseListResponse() {
        return new GetWarehouseListResponse();
    }

    /**
     * Create an instance of {@link LoginUser }
     * 
     */
    public LoginUser createLoginUser() {
        return new LoginUser();
    }

    /**
     * Create an instance of {@link Reload }
     * 
     */
    public Reload createReload() {
        return new Reload();
    }

    /**
     * Create an instance of {@link SaveReceipt }
     * 
     */
    public SaveReceipt createSaveReceipt() {
        return new SaveReceipt();
    }

    /**
     * Create an instance of {@link GetAllWarehouseListByUserDepartmentIDResponse }
     * 
     */
    public GetAllWarehouseListByUserDepartmentIDResponse createGetAllWarehouseListByUserDepartmentIDResponse() {
        return new GetAllWarehouseListByUserDepartmentIDResponse();
    }

    /**
     * Create an instance of {@link GetStockItemListResponse }
     * 
     */
    public GetStockItemListResponse createGetStockItemListResponse() {
        return new GetStockItemListResponse();
    }

    /**
     * Create an instance of {@link CreateSalesOrderResponse }
     * 
     */
    public CreateSalesOrderResponse createCreateSalesOrderResponse() {
        return new CreateSalesOrderResponse();
    }

    /**
     * Create an instance of {@link Validate }
     * 
     */
    public Validate createValidate() {
        return new Validate();
    }

    /**
     * Create an instance of {@link StartSessionResponse }
     * 
     */
    public StartSessionResponse createStartSessionResponse() {
        return new StartSessionResponse();
    }

    /**
     * Create an instance of {@link GetAllBanks }
     * 
     */
    public GetAllBanks createGetAllBanks() {
        return new GetAllBanks();
    }

    /**
     * Create an instance of {@link UploadReceiptResponse }
     * 
     */
    public UploadReceiptResponse createUploadReceiptResponse() {
        return new UploadReceiptResponse();
    }

    /**
     * Create an instance of {@link ValidateResponse }
     * 
     */
    public ValidateResponse createValidateResponse() {
        return new ValidateResponse();
    }

    /**
     * Create an instance of {@link CreateSalesOrder }
     * 
     */
    public CreateSalesOrder createCreateSalesOrder() {
        return new CreateSalesOrder();
    }

    /**
     * Create an instance of {@link GetAllDocuments }
     * 
     */
    public GetAllDocuments createGetAllDocuments() {
        return new GetAllDocuments();
    }

    /**
     * Create an instance of {@link GetAllWarehouseListByUserDepartmentID }
     * 
     */
    public GetAllWarehouseListByUserDepartmentID createGetAllWarehouseListByUserDepartmentID() {
        return new GetAllWarehouseListByUserDepartmentID();
    }

    /**
     * Create an instance of {@link GetStockItemListByWareHouseResponse }
     * 
     */
    public GetStockItemListByWareHouseResponse createGetStockItemListByWareHouseResponse() {
        return new GetStockItemListByWareHouseResponse();
    }

    /**
     * Create an instance of {@link GetRelatedStockItemListByIDResponse }
     * 
     */
    public GetRelatedStockItemListByIDResponse createGetRelatedStockItemListByIDResponse() {
        return new GetRelatedStockItemListByIDResponse();
    }

    /**
     * Create an instance of {@link GetSystemSettings }
     * 
     */
    public GetSystemSettings createGetSystemSettings() {
        return new GetSystemSettings();
    }

    /**
     * Create an instance of {@link GetSystemSettingsResponse }
     * 
     */
    public GetSystemSettingsResponse createGetSystemSettingsResponse() {
        return new GetSystemSettingsResponse();
    }

    /**
     * Create an instance of {@link GetDocumentsByRef }
     * 
     */
    public GetDocumentsByRef createGetDocumentsByRef() {
        return new GetDocumentsByRef();
    }

    /**
     * Create an instance of {@link GetStockItemListByWareHouse }
     * 
     */
    public GetStockItemListByWareHouse createGetStockItemListByWareHouse() {
        return new GetStockItemListByWareHouse();
    }

    /**
     * Create an instance of {@link SaveReceiptResponse }
     * 
     */
    public SaveReceiptResponse createSaveReceiptResponse() {
        return new SaveReceiptResponse();
    }

    /**
     * Create an instance of {@link FindStockRelationListByIDResponse }
     * 
     */
    public FindStockRelationListByIDResponse createFindStockRelationListByIDResponse() {
        return new FindStockRelationListByIDResponse();
    }

    /**
     * Create an instance of {@link GetStockItemListByCategoryResponse }
     * 
     */
    public GetStockItemListByCategoryResponse createGetStockItemListByCategoryResponse() {
        return new GetStockItemListByCategoryResponse();
    }

    /**
     * Create an instance of {@link GetStockItemListByItemTypeIDResponse }
     * 
     */
    public GetStockItemListByItemTypeIDResponse createGetStockItemListByItemTypeIDResponse() {
        return new GetStockItemListByItemTypeIDResponse();
    }

    /**
     * Create an instance of {@link SaveDocumentsResponse }
     * 
     */
    public SaveDocumentsResponse createSaveDocumentsResponse() {
        return new SaveDocumentsResponse();
    }

    /**
     * Create an instance of {@link SaveSettings }
     * 
     */
    public SaveSettings createSaveSettings() {
        return new SaveSettings();
    }

    /**
     * Create an instance of {@link Exception }
     * 
     */
    public Exception createException() {
        return new Exception();
    }

    /**
     * Create an instance of {@link GetStockItemCategoryList }
     * 
     */
    public GetStockItemCategoryList createGetStockItemCategoryList() {
        return new GetStockItemCategoryList();
    }

    /**
     * Create an instance of {@link GetAllBanksResponse }
     * 
     */
    public GetAllBanksResponse createGetAllBanksResponse() {
        return new GetAllBanksResponse();
    }

    /**
     * Create an instance of {@link GetDocumentsBySource }
     * 
     */
    public GetDocumentsBySource createGetDocumentsBySource() {
        return new GetDocumentsBySource();
    }

    /**
     * Create an instance of {@link FindStockItemByID }
     * 
     */
    public FindStockItemByID createFindStockItemByID() {
        return new FindStockItemByID();
    }

    /**
     * Create an instance of {@link ValidateUser }
     * 
     */
    public ValidateUser createValidateUser() {
        return new ValidateUser();
    }

    /**
     * Create an instance of {@link CreateReceipt }
     * 
     */
    public CreateReceipt createCreateReceipt() {
        return new CreateReceipt();
    }

    /**
     * Create an instance of {@link GetDocumentByID }
     * 
     */
    public GetDocumentByID createGetDocumentByID() {
        return new GetDocumentByID();
    }

    /**
     * Create an instance of {@link GetStockItemListByItemTypeID }
     * 
     */
    public GetStockItemListByItemTypeID createGetStockItemListByItemTypeID() {
        return new GetStockItemListByItemTypeID();
    }

    /**
     * Create an instance of {@link GetDocumentByName }
     * 
     */
    public GetDocumentByName createGetDocumentByName() {
        return new GetDocumentByName();
    }

    /**
     * Create an instance of {@link UploadReceipt }
     * 
     */
    public UploadReceipt createUploadReceipt() {
        return new UploadReceipt();
    }

    /**
     * Create an instance of {@link GetAllPromotions }
     * 
     */
    public GetAllPromotions createGetAllPromotions() {
        return new GetAllPromotions();
    }

    /**
     * Create an instance of {@link StockRelationDTO }
     * 
     */
    public StockRelationDTO createStockRelationDTO() {
        return new StockRelationDTO();
    }

    /**
     * Create an instance of {@link SalesOrderDTO }
     * 
     */
    public SalesOrderDTO createSalesOrderDTO() {
        return new SalesOrderDTO();
    }

    /**
     * Create an instance of {@link SalesPromotionDTO }
     * 
     */
    public SalesPromotionDTO createSalesPromotionDTO() {
        return new SalesPromotionDTO();
    }

    /**
     * Create an instance of {@link MiscAttributeDTO }
     * 
     */
    public MiscAttributeDTO createMiscAttributeDTO() {
        return new MiscAttributeDTO();
    }

    /**
     * Create an instance of {@link ClientRecordDTO }
     * 
     */
    public ClientRecordDTO createClientRecordDTO() {
        return new ClientRecordDTO();
    }

    /**
     * Create an instance of {@link SessionDTO }
     * 
     */
    public SessionDTO createSessionDTO() {
        return new SessionDTO();
    }

    /**
     * Create an instance of {@link WarehouseDTO }
     * 
     */
    public WarehouseDTO createWarehouseDTO() {
        return new WarehouseDTO();
    }

    /**
     * Create an instance of {@link SettingsDTO }
     * 
     */
    public SettingsDTO createSettingsDTO() {
        return new SettingsDTO();
    }

    /**
     * Create an instance of {@link PromotionCodeDTO }
     * 
     */
    public PromotionCodeDTO createPromotionCodeDTO() {
        return new PromotionCodeDTO();
    }

    /**
     * Create an instance of {@link UserAccountDTO }
     * 
     */
    public UserAccountDTO createUserAccountDTO() {
        return new UserAccountDTO();
    }

    /**
     * Create an instance of {@link StockActiveIngredientDTO }
     * 
     */
    public StockActiveIngredientDTO createStockActiveIngredientDTO() {
        return new StockActiveIngredientDTO();
    }

    /**
     * Create an instance of {@link ReceiptDTO }
     * 
     */
    public ReceiptDTO createReceiptDTO() {
        return new ReceiptDTO();
    }

    /**
     * Create an instance of {@link StockItemCategoryDTO }
     * 
     */
    public StockItemCategoryDTO createStockItemCategoryDTO() {
        return new StockItemCategoryDTO();
    }

    /**
     * Create an instance of {@link SalesOrderItemDTO }
     * 
     */
    public SalesOrderItemDTO createSalesOrderItemDTO() {
        return new SalesOrderItemDTO();
    }

    /**
     * Create an instance of {@link PromotionRewardDTO }
     * 
     */
    public PromotionRewardDTO createPromotionRewardDTO() {
        return new PromotionRewardDTO();
    }

    /**
     * Create an instance of {@link StockItemDTO }
     * 
     */
    public StockItemDTO createStockItemDTO() {
        return new StockItemDTO();
    }

    /**
     * Create an instance of {@link BankDTO }
     * 
     */
    public BankDTO createBankDTO() {
        return new BankDTO();
    }

    /**
     * Create an instance of {@link DocumentDTO }
     * 
     */
    public DocumentDTO createDocumentDTO() {
        return new DocumentDTO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetClientRecordListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getClientRecordListResponse")
    public JAXBElement<GetClientRecordListResponse> createGetClientRecordListResponse(GetClientRecordListResponse value) {
        return new JAXBElement<GetClientRecordListResponse>(_GetClientRecordListResponse_QNAME, GetClientRecordListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClientRecordNotFoundException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "ClientRecordNotFoundException")
    public JAXBElement<ClientRecordNotFoundException> createClientRecordNotFoundException(ClientRecordNotFoundException value) {
        return new JAXBElement<ClientRecordNotFoundException>(_ClientRecordNotFoundException_QNAME, ClientRecordNotFoundException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllSessionResponse")
    public JAXBElement<GetAllSessionResponse> createGetAllSessionResponse(GetAllSessionResponse value) {
        return new JAXBElement<GetAllSessionResponse>(_GetAllSessionResponse_QNAME, GetAllSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindStockItemByIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "findStockItemByIDResponse")
    public JAXBElement<FindStockItemByIDResponse> createFindStockItemByIDResponse(FindStockItemByIDResponse value) {
        return new JAXBElement<FindStockItemByIDResponse>(_FindStockItemByIDResponse_QNAME, FindStockItemByIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWarehouseList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getWarehouseList")
    public JAXBElement<GetWarehouseList> createGetWarehouseList(GetWarehouseList value) {
        return new JAXBElement<GetWarehouseList>(_GetWarehouseList_QNAME, GetWarehouseList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReloadResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "reloadResponse")
    public JAXBElement<ReloadResponse> createReloadResponse(ReloadResponse value) {
        return new JAXBElement<ReloadResponse>(_ReloadResponse_QNAME, ReloadResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentsByRefResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentsByRefResponse")
    public JAXBElement<GetDocumentsByRefResponse> createGetDocumentsByRefResponse(GetDocumentsByRefResponse value) {
        return new JAXBElement<GetDocumentsByRefResponse>(_GetDocumentsByRefResponse_QNAME, GetDocumentsByRefResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByActiveIngredientID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByActiveIngredientID")
    public JAXBElement<GetStockItemListByActiveIngredientID> createGetStockItemListByActiveIngredientID(GetStockItemListByActiveIngredientID value) {
        return new JAXBElement<GetStockItemListByActiveIngredientID>(_GetStockItemListByActiveIngredientID_QNAME, GetStockItemListByActiveIngredientID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllPromotionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllPromotionsResponse")
    public JAXBElement<GetAllPromotionsResponse> createGetAllPromotionsResponse(GetAllPromotionsResponse value) {
        return new JAXBElement<GetAllPromotionsResponse>(_GetAllPromotionsResponse_QNAME, GetAllPromotionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListResponse")
    public JAXBElement<GetStockItemListResponse> createGetStockItemListResponse(GetStockItemListResponse value) {
        return new JAXBElement<GetStockItemListResponse>(_GetStockItemListResponse_QNAME, GetStockItemListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateSalesOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "createSalesOrderResponse")
    public JAXBElement<CreateSalesOrderResponse> createCreateSalesOrderResponse(CreateSalesOrderResponse value) {
        return new JAXBElement<CreateSalesOrderResponse>(_CreateSalesOrderResponse_QNAME, CreateSalesOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Validate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "validate")
    public JAXBElement<Validate> createValidate(Validate value) {
        return new JAXBElement<Validate>(_Validate_QNAME, Validate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllWarehouseListByUserDepartmentIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllWarehouseListByUserDepartmentIDResponse")
    public JAXBElement<GetAllWarehouseListByUserDepartmentIDResponse> createGetAllWarehouseListByUserDepartmentIDResponse(GetAllWarehouseListByUserDepartmentIDResponse value) {
        return new JAXBElement<GetAllWarehouseListByUserDepartmentIDResponse>(_GetAllWarehouseListByUserDepartmentIDResponse_QNAME, GetAllWarehouseListByUserDepartmentIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveReceipt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveReceipt")
    public JAXBElement<SaveReceipt> createSaveReceipt(SaveReceipt value) {
        return new JAXBElement<SaveReceipt>(_SaveReceipt_QNAME, SaveReceipt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllSession")
    public JAXBElement<GetAllSession> createGetAllSession(GetAllSession value) {
        return new JAXBElement<GetAllSession>(_GetAllSession_QNAME, GetAllSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWarehouseListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getWarehouseListResponse")
    public JAXBElement<GetWarehouseListResponse> createGetWarehouseListResponse(GetWarehouseListResponse value) {
        return new JAXBElement<GetWarehouseListResponse>(_GetWarehouseListResponse_QNAME, GetWarehouseListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoginUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "loginUser")
    public JAXBElement<LoginUser> createLoginUser(LoginUser value) {
        return new JAXBElement<LoginUser>(_LoginUser_QNAME, LoginUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Reload }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "reload")
    public JAXBElement<Reload> createReload(Reload value) {
        return new JAXBElement<Reload>(_Reload_QNAME, Reload.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveDocumentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveDocumentsResponse")
    public JAXBElement<SaveDocumentsResponse> createSaveDocumentsResponse(SaveDocumentsResponse value) {
        return new JAXBElement<SaveDocumentsResponse>(_SaveDocumentsResponse_QNAME, SaveDocumentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveSettings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveSettings")
    public JAXBElement<SaveSettings> createSaveSettings(SaveSettings value) {
        return new JAXBElement<SaveSettings>(_SaveSettings_QNAME, SaveSettings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exception }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "Exception")
    public JAXBElement<Exception> createException(Exception value) {
        return new JAXBElement<Exception>(_Exception_QNAME, Exception.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemCategoryList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemCategoryList")
    public JAXBElement<GetStockItemCategoryList> createGetStockItemCategoryList(GetStockItemCategoryList value) {
        return new JAXBElement<GetStockItemCategoryList>(_GetStockItemCategoryList_QNAME, GetStockItemCategoryList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentsByRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentsByRef")
    public JAXBElement<GetDocumentsByRef> createGetDocumentsByRef(GetDocumentsByRef value) {
        return new JAXBElement<GetDocumentsByRef>(_GetDocumentsByRef_QNAME, GetDocumentsByRef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByWareHouse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByWareHouse")
    public JAXBElement<GetStockItemListByWareHouse> createGetStockItemListByWareHouse(GetStockItemListByWareHouse value) {
        return new JAXBElement<GetStockItemListByWareHouse>(_GetStockItemListByWareHouse_QNAME, GetStockItemListByWareHouse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveReceiptResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveReceiptResponse")
    public JAXBElement<SaveReceiptResponse> createSaveReceiptResponse(SaveReceiptResponse value) {
        return new JAXBElement<SaveReceiptResponse>(_SaveReceiptResponse_QNAME, SaveReceiptResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindStockRelationListByIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "findStockRelationListByIDResponse")
    public JAXBElement<FindStockRelationListByIDResponse> createFindStockRelationListByIDResponse(FindStockRelationListByIDResponse value) {
        return new JAXBElement<FindStockRelationListByIDResponse>(_FindStockRelationListByIDResponse_QNAME, FindStockRelationListByIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByCategoryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByCategoryResponse")
    public JAXBElement<GetStockItemListByCategoryResponse> createGetStockItemListByCategoryResponse(GetStockItemListByCategoryResponse value) {
        return new JAXBElement<GetStockItemListByCategoryResponse>(_GetStockItemListByCategoryResponse_QNAME, GetStockItemListByCategoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByItemTypeIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByItemTypeIDResponse")
    public JAXBElement<GetStockItemListByItemTypeIDResponse> createGetStockItemListByItemTypeIDResponse(GetStockItemListByItemTypeIDResponse value) {
        return new JAXBElement<GetStockItemListByItemTypeIDResponse>(_GetStockItemListByItemTypeIDResponse_QNAME, GetStockItemListByItemTypeIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllBanks }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllBanks")
    public JAXBElement<GetAllBanks> createGetAllBanks(GetAllBanks value) {
        return new JAXBElement<GetAllBanks>(_GetAllBanks_QNAME, GetAllBanks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadReceiptResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "uploadReceiptResponse")
    public JAXBElement<UploadReceiptResponse> createUploadReceiptResponse(UploadReceiptResponse value) {
        return new JAXBElement<UploadReceiptResponse>(_UploadReceiptResponse_QNAME, UploadReceiptResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "validateResponse")
    public JAXBElement<ValidateResponse> createValidateResponse(ValidateResponse value) {
        return new JAXBElement<ValidateResponse>(_ValidateResponse_QNAME, ValidateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateSalesOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "createSalesOrder")
    public JAXBElement<CreateSalesOrder> createCreateSalesOrder(CreateSalesOrder value) {
        return new JAXBElement<CreateSalesOrder>(_CreateSalesOrder_QNAME, CreateSalesOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllDocuments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllDocuments")
    public JAXBElement<GetAllDocuments> createGetAllDocuments(GetAllDocuments value) {
        return new JAXBElement<GetAllDocuments>(_GetAllDocuments_QNAME, GetAllDocuments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllWarehouseListByUserDepartmentID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllWarehouseListByUserDepartmentID")
    public JAXBElement<GetAllWarehouseListByUserDepartmentID> createGetAllWarehouseListByUserDepartmentID(GetAllWarehouseListByUserDepartmentID value) {
        return new JAXBElement<GetAllWarehouseListByUserDepartmentID>(_GetAllWarehouseListByUserDepartmentID_QNAME, GetAllWarehouseListByUserDepartmentID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByWareHouseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByWareHouseResponse")
    public JAXBElement<GetStockItemListByWareHouseResponse> createGetStockItemListByWareHouseResponse(GetStockItemListByWareHouseResponse value) {
        return new JAXBElement<GetStockItemListByWareHouseResponse>(_GetStockItemListByWareHouseResponse_QNAME, GetStockItemListByWareHouseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRelatedStockItemListByIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getRelatedStockItemListByIDResponse")
    public JAXBElement<GetRelatedStockItemListByIDResponse> createGetRelatedStockItemListByIDResponse(GetRelatedStockItemListByIDResponse value) {
        return new JAXBElement<GetRelatedStockItemListByIDResponse>(_GetRelatedStockItemListByIDResponse_QNAME, GetRelatedStockItemListByIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSystemSettings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getSystemSettings")
    public JAXBElement<GetSystemSettings> createGetSystemSettings(GetSystemSettings value) {
        return new JAXBElement<GetSystemSettings>(_GetSystemSettings_QNAME, GetSystemSettings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSystemSettingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getSystemSettingsResponse")
    public JAXBElement<GetSystemSettingsResponse> createGetSystemSettingsResponse(GetSystemSettingsResponse value) {
        return new JAXBElement<GetSystemSettingsResponse>(_GetSystemSettingsResponse_QNAME, GetSystemSettingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StartSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "startSessionResponse")
    public JAXBElement<StartSessionResponse> createStartSessionResponse(StartSessionResponse value) {
        return new JAXBElement<StartSessionResponse>(_StartSessionResponse_QNAME, StartSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllPromotions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllPromotions")
    public JAXBElement<GetAllPromotions> createGetAllPromotions(GetAllPromotions value) {
        return new JAXBElement<GetAllPromotions>(_GetAllPromotions_QNAME, GetAllPromotions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentByID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentByID")
    public JAXBElement<GetDocumentByID> createGetDocumentByID(GetDocumentByID value) {
        return new JAXBElement<GetDocumentByID>(_GetDocumentByID_QNAME, GetDocumentByID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByItemTypeID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByItemTypeID")
    public JAXBElement<GetStockItemListByItemTypeID> createGetStockItemListByItemTypeID(GetStockItemListByItemTypeID value) {
        return new JAXBElement<GetStockItemListByItemTypeID>(_GetStockItemListByItemTypeID_QNAME, GetStockItemListByItemTypeID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentByName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentByName")
    public JAXBElement<GetDocumentByName> createGetDocumentByName(GetDocumentByName value) {
        return new JAXBElement<GetDocumentByName>(_GetDocumentByName_QNAME, GetDocumentByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadReceipt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "uploadReceipt")
    public JAXBElement<UploadReceipt> createUploadReceipt(UploadReceipt value) {
        return new JAXBElement<UploadReceipt>(_UploadReceipt_QNAME, UploadReceipt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateReceipt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "createReceipt")
    public JAXBElement<CreateReceipt> createCreateReceipt(CreateReceipt value) {
        return new JAXBElement<CreateReceipt>(_CreateReceipt_QNAME, CreateReceipt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllBanksResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllBanksResponse")
    public JAXBElement<GetAllBanksResponse> createGetAllBanksResponse(GetAllBanksResponse value) {
        return new JAXBElement<GetAllBanksResponse>(_GetAllBanksResponse_QNAME, GetAllBanksResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentsBySource }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentsBySource")
    public JAXBElement<GetDocumentsBySource> createGetDocumentsBySource(GetDocumentsBySource value) {
        return new JAXBElement<GetDocumentsBySource>(_GetDocumentsBySource_QNAME, GetDocumentsBySource.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindStockItemByID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "findStockItemByID")
    public JAXBElement<FindStockItemByID> createFindStockItemByID(FindStockItemByID value) {
        return new JAXBElement<FindStockItemByID>(_FindStockItemByID_QNAME, FindStockItemByID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "validateUser")
    public JAXBElement<ValidateUser> createValidateUser(ValidateUser value) {
        return new JAXBElement<ValidateUser>(_ValidateUser_QNAME, ValidateUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetActivePromotionListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getActivePromotionListResponse")
    public JAXBElement<GetActivePromotionListResponse> createGetActivePromotionListResponse(GetActivePromotionListResponse value) {
        return new JAXBElement<GetActivePromotionListResponse>(_GetActivePromotionListResponse_QNAME, GetActivePromotionListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllWarehouseListByUserBranchIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllWarehouseListByUserBranchIDResponse")
    public JAXBElement<GetAllWarehouseListByUserBranchIDResponse> createGetAllWarehouseListByUserBranchIDResponse(GetAllWarehouseListByUserBranchIDResponse value) {
        return new JAXBElement<GetAllWarehouseListByUserBranchIDResponse>(_GetAllWarehouseListByUserBranchIDResponse_QNAME, GetAllWarehouseListByUserBranchIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "uploadSession")
    public JAXBElement<UploadSession> createUploadSession(UploadSession value) {
        return new JAXBElement<UploadSession>(_UploadSession_QNAME, UploadSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StopSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "stopSession")
    public JAXBElement<StopSession> createStopSession(StopSession value) {
        return new JAXBElement<StopSession>(_StopSession_QNAME, StopSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateUserResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "validateUserResponse")
    public JAXBElement<ValidateUserResponse> createValidateUserResponse(ValidateUserResponse value) {
        return new JAXBElement<ValidateUserResponse>(_ValidateUserResponse_QNAME, ValidateUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByActiveIngredientIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByActiveIngredientIDResponse")
    public JAXBElement<GetStockItemListByActiveIngredientIDResponse> createGetStockItemListByActiveIngredientIDResponse(GetStockItemListByActiveIngredientIDResponse value) {
        return new JAXBElement<GetStockItemListByActiveIngredientIDResponse>(_GetStockItemListByActiveIngredientIDResponse_QNAME, GetStockItemListByActiveIngredientIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoginUserResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "loginUserResponse")
    public JAXBElement<LoginUserResponse> createLoginUserResponse(LoginUserResponse value) {
        return new JAXBElement<LoginUserResponse>(_LoginUserResponse_QNAME, LoginUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveDocuments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveDocuments")
    public JAXBElement<SaveDocuments> createSaveDocuments(SaveDocuments value) {
        return new JAXBElement<SaveDocuments>(_SaveDocuments_QNAME, SaveDocuments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllWarehouseListByUserBranchID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllWarehouseListByUserBranchID")
    public JAXBElement<GetAllWarehouseListByUserBranchID> createGetAllWarehouseListByUserBranchID(GetAllWarehouseListByUserBranchID value) {
        return new JAXBElement<GetAllWarehouseListByUserBranchID>(_GetAllWarehouseListByUserBranchID_QNAME, GetAllWarehouseListByUserBranchID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentByNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentByNameResponse")
    public JAXBElement<GetDocumentByNameResponse> createGetDocumentByNameResponse(GetDocumentByNameResponse value) {
        return new JAXBElement<GetDocumentByNameResponse>(_GetDocumentByNameResponse_QNAME, GetDocumentByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveSettingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveSettingsResponse")
    public JAXBElement<SaveSettingsResponse> createSaveSettingsResponse(SaveSettingsResponse value) {
        return new JAXBElement<SaveSettingsResponse>(_SaveSettingsResponse_QNAME, SaveSettingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StopSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "stopSessionResponse")
    public JAXBElement<StopSessionResponse> createStopSessionResponse(StopSessionResponse value) {
        return new JAXBElement<StopSessionResponse>(_StopSessionResponse_QNAME, StopSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StartSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "startSession")
    public JAXBElement<StartSession> createStartSession(StartSession value) {
        return new JAXBElement<StartSession>(_StartSession_QNAME, StartSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentByIDResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentByIDResponse")
    public JAXBElement<GetDocumentByIDResponse> createGetDocumentByIDResponse(GetDocumentByIDResponse value) {
        return new JAXBElement<GetDocumentByIDResponse>(_GetDocumentByIDResponse_QNAME, GetDocumentByIDResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRelatedStockItemListByID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getRelatedStockItemListByID")
    public JAXBElement<GetRelatedStockItemListByID> createGetRelatedStockItemListByID(GetRelatedStockItemListByID value) {
        return new JAXBElement<GetRelatedStockItemListByID>(_GetRelatedStockItemListByID_QNAME, GetRelatedStockItemListByID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemListByCategory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemListByCategory")
    public JAXBElement<GetStockItemListByCategory> createGetStockItemListByCategory(GetStockItemListByCategory value) {
        return new JAXBElement<GetStockItemListByCategory>(_GetStockItemListByCategory_QNAME, GetStockItemListByCategory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveDocumentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveDocumentResponse")
    public JAXBElement<SaveDocumentResponse> createSaveDocumentResponse(SaveDocumentResponse value) {
        return new JAXBElement<SaveDocumentResponse>(_SaveDocumentResponse_QNAME, SaveDocumentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetActivePromotionList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getActivePromotionList")
    public JAXBElement<GetActivePromotionList> createGetActivePromotionList(GetActivePromotionList value) {
        return new JAXBElement<GetActivePromotionList>(_GetActivePromotionList_QNAME, GetActivePromotionList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "uploadSessionResponse")
    public JAXBElement<UploadSessionResponse> createUploadSessionResponse(UploadSessionResponse value) {
        return new JAXBElement<UploadSessionResponse>(_UploadSessionResponse_QNAME, UploadSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentsBySourceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getDocumentsBySourceResponse")
    public JAXBElement<GetDocumentsBySourceResponse> createGetDocumentsBySourceResponse(GetDocumentsBySourceResponse value) {
        return new JAXBElement<GetDocumentsBySourceResponse>(_GetDocumentsBySourceResponse_QNAME, GetDocumentsBySourceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemCategoryListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemCategoryListResponse")
    public JAXBElement<GetStockItemCategoryListResponse> createGetStockItemCategoryListResponse(GetStockItemCategoryListResponse value) {
        return new JAXBElement<GetStockItemCategoryListResponse>(_GetStockItemCategoryListResponse_QNAME, GetStockItemCategoryListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetClientRecordList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getClientRecordList")
    public JAXBElement<GetClientRecordList> createGetClientRecordList(GetClientRecordList value) {
        return new JAXBElement<GetClientRecordList>(_GetClientRecordList_QNAME, GetClientRecordList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "saveDocument")
    public JAXBElement<SaveDocument> createSaveDocument(SaveDocument value) {
        return new JAXBElement<SaveDocument>(_SaveDocument_QNAME, SaveDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStockItemList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getStockItemList")
    public JAXBElement<GetStockItemList> createGetStockItemList(GetStockItemList value) {
        return new JAXBElement<GetStockItemList>(_GetStockItemList_QNAME, GetStockItemList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateReceiptResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "createReceiptResponse")
    public JAXBElement<CreateReceiptResponse> createCreateReceiptResponse(CreateReceiptResponse value) {
        return new JAXBElement<CreateReceiptResponse>(_CreateReceiptResponse_QNAME, CreateReceiptResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllDocumentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "getAllDocumentsResponse")
    public JAXBElement<GetAllDocumentsResponse> createGetAllDocumentsResponse(GetAllDocumentsResponse value) {
        return new JAXBElement<GetAllDocumentsResponse>(_GetAllDocumentsResponse_QNAME, GetAllDocumentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindStockRelationListByID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.endpoint.business.rsdynamix.com/", name = "findStockRelationListByID")
    public JAXBElement<FindStockRelationListByID> createFindStockRelationListByID(FindStockRelationListByID value) {
        return new JAXBElement<FindStockRelationListByID>(_FindStockRelationListByID_QNAME, FindStockRelationListByID.class, null, value);
    }

}
