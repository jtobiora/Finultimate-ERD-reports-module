
package com.s3.systems.reporting.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="documentID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="documentImage" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="documentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="documentRefrence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="documentSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentDTO", propOrder = {
    "documentID",
    "documentImage",
    "documentName",
    "documentRefrence",
    "documentSource"
})
public class DocumentDTO {

    protected long documentID;
    protected byte[] documentImage;
    protected String documentName;
    protected String documentRefrence;
    protected String documentSource;

    /**
     * Gets the value of the documentID property.
     * 
     */
    public long getDocumentID() {
        return documentID;
    }

    /**
     * Sets the value of the documentID property.
     * 
     */
    public void setDocumentID(long value) {
        this.documentID = value;
    }

    /**
     * Gets the value of the documentImage property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getDocumentImage() {
        return documentImage;
    }

    /**
     * Sets the value of the documentImage property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setDocumentImage(byte[] value) {
        this.documentImage = value;
    }

    /**
     * Gets the value of the documentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentName() {
        return documentName;
    }

    /**
     * Sets the value of the documentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentName(String value) {
        this.documentName = value;
    }

    /**
     * Gets the value of the documentRefrence property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentRefrence() {
        return documentRefrence;
    }

    /**
     * Sets the value of the documentRefrence property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentRefrence(String value) {
        this.documentRefrence = value;
    }

    /**
     * Gets the value of the documentSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentSource() {
        return documentSource;
    }

    /**
     * Sets the value of the documentSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentSource(String value) {
        this.documentSource = value;
    }

}
