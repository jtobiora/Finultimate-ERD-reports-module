
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for receiptDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="receiptDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="amount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="budgetEntryID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loyaltyAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="narration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="netFlag" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="payer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payerPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentChannelID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="paymentDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="paymentTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentTypeID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pensionFundAdminID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="pfaCompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="posReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="receiptNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="referenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="subsystemID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="subsystemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="timeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="transactionSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unallocatedAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "receiptDTO", propOrder = {
    "address",
    "amount",
    "budgetEntryID",
    "currencyCode",
    "loyaltyAmount",
    "narration",
    "netFlag",
    "payer",
    "payerPhone",
    "paymentChannelID",
    "paymentDate",
    "paymentTypeDesc",
    "paymentTypeID",
    "pensionFundAdminID",
    "pfaCompanyName",
    "posReferenceNumber",
    "receiptNumber",
    "referenceNumber",
    "subsystemID",
    "subsystemName",
    "timeStamp",
    "transactionSource",
    "unallocatedAmount",
    "userName"
})
public class ReceiptDTO {

    protected String address;
    protected double amount;
    protected long budgetEntryID;
    protected String currencyCode;
    protected double loyaltyAmount;
    protected String narration;
    protected int netFlag;
    protected String payer;
    protected String payerPhone;
    protected int paymentChannelID;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar paymentDate;
    protected String paymentTypeDesc;
    protected int paymentTypeID;
    protected long pensionFundAdminID;
    protected String pfaCompanyName;
    protected String posReferenceNumber;
    protected String receiptNumber;
    protected String referenceNumber;
    protected int subsystemID;
    protected String subsystemName;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timeStamp;
    protected String transactionSource;
    protected double unallocatedAmount;
    protected String userName;

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     */
    public void setAmount(double value) {
        this.amount = value;
    }

    /**
     * Gets the value of the budgetEntryID property.
     * 
     */
    public long getBudgetEntryID() {
        return budgetEntryID;
    }

    /**
     * Sets the value of the budgetEntryID property.
     * 
     */
    public void setBudgetEntryID(long value) {
        this.budgetEntryID = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the loyaltyAmount property.
     * 
     */
    public double getLoyaltyAmount() {
        return loyaltyAmount;
    }

    /**
     * Sets the value of the loyaltyAmount property.
     * 
     */
    public void setLoyaltyAmount(double value) {
        this.loyaltyAmount = value;
    }

    /**
     * Gets the value of the narration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNarration() {
        return narration;
    }

    /**
     * Sets the value of the narration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNarration(String value) {
        this.narration = value;
    }

    /**
     * Gets the value of the netFlag property.
     * 
     */
    public int getNetFlag() {
        return netFlag;
    }

    /**
     * Sets the value of the netFlag property.
     * 
     */
    public void setNetFlag(int value) {
        this.netFlag = value;
    }

    /**
     * Gets the value of the payer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayer() {
        return payer;
    }

    /**
     * Sets the value of the payer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayer(String value) {
        this.payer = value;
    }

    /**
     * Gets the value of the payerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayerPhone() {
        return payerPhone;
    }

    /**
     * Sets the value of the payerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayerPhone(String value) {
        this.payerPhone = value;
    }

    /**
     * Gets the value of the paymentChannelID property.
     * 
     */
    public int getPaymentChannelID() {
        return paymentChannelID;
    }

    /**
     * Sets the value of the paymentChannelID property.
     * 
     */
    public void setPaymentChannelID(int value) {
        this.paymentChannelID = value;
    }

    /**
     * Gets the value of the paymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPaymentDate() {
        return paymentDate;
    }

    /**
     * Sets the value of the paymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPaymentDate(XMLGregorianCalendar value) {
        this.paymentDate = value;
    }

    /**
     * Gets the value of the paymentTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentTypeDesc() {
        return paymentTypeDesc;
    }

    /**
     * Sets the value of the paymentTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentTypeDesc(String value) {
        this.paymentTypeDesc = value;
    }

    /**
     * Gets the value of the paymentTypeID property.
     * 
     */
    public int getPaymentTypeID() {
        return paymentTypeID;
    }

    /**
     * Sets the value of the paymentTypeID property.
     * 
     */
    public void setPaymentTypeID(int value) {
        this.paymentTypeID = value;
    }

    /**
     * Gets the value of the pensionFundAdminID property.
     * 
     */
    public long getPensionFundAdminID() {
        return pensionFundAdminID;
    }

    /**
     * Sets the value of the pensionFundAdminID property.
     * 
     */
    public void setPensionFundAdminID(long value) {
        this.pensionFundAdminID = value;
    }

    /**
     * Gets the value of the pfaCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPfaCompanyName() {
        return pfaCompanyName;
    }

    /**
     * Sets the value of the pfaCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPfaCompanyName(String value) {
        this.pfaCompanyName = value;
    }

    /**
     * Gets the value of the posReferenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPosReferenceNumber() {
        return posReferenceNumber;
    }

    /**
     * Sets the value of the posReferenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPosReferenceNumber(String value) {
        this.posReferenceNumber = value;
    }

    /**
     * Gets the value of the receiptNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptNumber() {
        return receiptNumber;
    }

    /**
     * Sets the value of the receiptNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptNumber(String value) {
        this.receiptNumber = value;
    }

    /**
     * Gets the value of the referenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNumber() {
        return referenceNumber;
    }

    /**
     * Sets the value of the referenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNumber(String value) {
        this.referenceNumber = value;
    }

    /**
     * Gets the value of the subsystemID property.
     * 
     */
    public int getSubsystemID() {
        return subsystemID;
    }

    /**
     * Sets the value of the subsystemID property.
     * 
     */
    public void setSubsystemID(int value) {
        this.subsystemID = value;
    }

    /**
     * Gets the value of the subsystemName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsystemName() {
        return subsystemName;
    }

    /**
     * Sets the value of the subsystemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsystemName(String value) {
        this.subsystemName = value;
    }

    /**
     * Gets the value of the timeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTimeStamp() {
        return timeStamp;
    }

    /**
     * Sets the value of the timeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTimeStamp(XMLGregorianCalendar value) {
        this.timeStamp = value;
    }

    /**
     * Gets the value of the transactionSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionSource() {
        return transactionSource;
    }

    /**
     * Sets the value of the transactionSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionSource(String value) {
        this.transactionSource = value;
    }

    /**
     * Gets the value of the unallocatedAmount property.
     * 
     */
    public double getUnallocatedAmount() {
        return unallocatedAmount;
    }

    /**
     * Sets the value of the unallocatedAmount property.
     * 
     */
    public void setUnallocatedAmount(double value) {
        this.unallocatedAmount = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

}
