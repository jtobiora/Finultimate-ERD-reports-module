
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for settingsDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="settingsDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="settingsID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="settingsName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="settingsValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "settingsDTO", propOrder = {
    "settingsID",
    "settingsName",
    "settingsValue"
})
public class SettingsDTO {

    protected long settingsID;
    protected String settingsName;
    protected String settingsValue;

    /**
     * Gets the value of the settingsID property.
     * 
     */
    public long getSettingsID() {
        return settingsID;
    }

    /**
     * Sets the value of the settingsID property.
     * 
     */
    public void setSettingsID(long value) {
        this.settingsID = value;
    }

    /**
     * Gets the value of the settingsName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettingsName() {
        return settingsName;
    }

    /**
     * Sets the value of the settingsName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettingsName(String value) {
        this.settingsName = value;
    }

    /**
     * Gets the value of the settingsValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettingsValue() {
        return settingsValue;
    }

    /**
     * Sets the value of the settingsValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettingsValue(String value) {
        this.settingsValue = value;
    }

}
