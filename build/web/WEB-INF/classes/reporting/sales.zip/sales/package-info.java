@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.endpoint.business.rsdynamix.com/")
package com.s3systems.remote.sales;
