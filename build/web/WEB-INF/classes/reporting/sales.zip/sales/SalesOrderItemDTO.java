
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for salesOrderItemDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="salesOrderItemDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="amount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="costOfSales" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="discountAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="layaltyPoints" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="orderItemID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="quantity" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="salesOrderID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="stockItemID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="stockItemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="unitPrice" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="warehouseID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "salesOrderItemDTO", propOrder = {
    "amount",
    "costOfSales",
    "currencyCode",
    "discountAmount",
    "layaltyPoints",
    "orderItemID",
    "quantity",
    "salesOrderID",
    "stockItemID",
    "stockItemName",
    "transactAmount",
    "unitPrice",
    "warehouseID"
})
public class SalesOrderItemDTO {

    protected double amount;
    protected double costOfSales;
    protected String currencyCode;
    protected double discountAmount;
    protected int layaltyPoints;
    protected long orderItemID;
    protected long quantity;
    protected long salesOrderID;
    protected long stockItemID;
    protected String stockItemName;
    protected double transactAmount;
    protected double unitPrice;
    protected long warehouseID;

    /**
     * Gets the value of the amount property.
     * 
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     */
    public void setAmount(double value) {
        this.amount = value;
    }

    /**
     * Gets the value of the costOfSales property.
     * 
     */
    public double getCostOfSales() {
        return costOfSales;
    }

    /**
     * Sets the value of the costOfSales property.
     * 
     */
    public void setCostOfSales(double value) {
        this.costOfSales = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the discountAmount property.
     * 
     */
    public double getDiscountAmount() {
        return discountAmount;
    }

    /**
     * Sets the value of the discountAmount property.
     * 
     */
    public void setDiscountAmount(double value) {
        this.discountAmount = value;
    }

    /**
     * Gets the value of the layaltyPoints property.
     * 
     */
    public int getLayaltyPoints() {
        return layaltyPoints;
    }

    /**
     * Sets the value of the layaltyPoints property.
     * 
     */
    public void setLayaltyPoints(int value) {
        this.layaltyPoints = value;
    }

    /**
     * Gets the value of the orderItemID property.
     * 
     */
    public long getOrderItemID() {
        return orderItemID;
    }

    /**
     * Sets the value of the orderItemID property.
     * 
     */
    public void setOrderItemID(long value) {
        this.orderItemID = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     */
    public long getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     */
    public void setQuantity(long value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the salesOrderID property.
     * 
     */
    public long getSalesOrderID() {
        return salesOrderID;
    }

    /**
     * Sets the value of the salesOrderID property.
     * 
     */
    public void setSalesOrderID(long value) {
        this.salesOrderID = value;
    }

    /**
     * Gets the value of the stockItemID property.
     * 
     */
    public long getStockItemID() {
        return stockItemID;
    }

    /**
     * Sets the value of the stockItemID property.
     * 
     */
    public void setStockItemID(long value) {
        this.stockItemID = value;
    }

    /**
     * Gets the value of the stockItemName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockItemName() {
        return stockItemName;
    }

    /**
     * Sets the value of the stockItemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockItemName(String value) {
        this.stockItemName = value;
    }

    /**
     * Gets the value of the transactAmount property.
     * 
     */
    public double getTransactAmount() {
        return transactAmount;
    }

    /**
     * Sets the value of the transactAmount property.
     * 
     */
    public void setTransactAmount(double value) {
        this.transactAmount = value;
    }

    /**
     * Gets the value of the unitPrice property.
     * 
     */
    public double getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the value of the unitPrice property.
     * 
     */
    public void setUnitPrice(double value) {
        this.unitPrice = value;
    }

    /**
     * Gets the value of the warehouseID property.
     * 
     */
    public long getWarehouseID() {
        return warehouseID;
    }

    /**
     * Sets the value of the warehouseID property.
     * 
     */
    public void setWarehouseID(long value) {
        this.warehouseID = value;
    }

}
