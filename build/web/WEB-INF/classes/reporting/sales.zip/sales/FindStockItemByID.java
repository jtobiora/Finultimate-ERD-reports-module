
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for findStockItemByID complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="findStockItemByID">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="stockItemID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="userAccount" type="{http://services.endpoint.business.rsdynamix.com/}userAccountDTO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findStockItemByID", propOrder = {
    "stockItemID",
    "userAccount"
})
public class FindStockItemByID {

    protected long stockItemID;
    protected UserAccountDTO userAccount;

    /**
     * Gets the value of the stockItemID property.
     * 
     */
    public long getStockItemID() {
        return stockItemID;
    }

    /**
     * Sets the value of the stockItemID property.
     * 
     */
    public void setStockItemID(long value) {
        this.stockItemID = value;
    }

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountDTO }
     *     
     */
    public UserAccountDTO getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountDTO }
     *     
     */
    public void setUserAccount(UserAccountDTO value) {
        this.userAccount = value;
    }

}
