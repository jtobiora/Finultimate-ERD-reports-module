
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for promotionRewardDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="promotionRewardDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="maximumPurchaseAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="minimumPurchaseAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="numberOfPoints" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="promotionAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="promotionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="promotionRewardID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="quantity" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="rateType" type="{http://services.endpoint.business.rsdynamix.com/}rateType" minOccurs="0"/>
 *         &lt;element name="stockItemDTO" type="{http://services.endpoint.business.rsdynamix.com/}stockItemDTO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "promotionRewardDTO", propOrder = {
    "maximumPurchaseAmount",
    "minimumPurchaseAmount",
    "numberOfPoints",
    "promotionAmount",
    "promotionID",
    "promotionRewardID",
    "quantity",
    "rateType",
    "stockItemDTO"
})
public class PromotionRewardDTO {

    protected double maximumPurchaseAmount;
    protected double minimumPurchaseAmount;
    protected int numberOfPoints;
    protected double promotionAmount;
    protected long promotionID;
    protected long promotionRewardID;
    protected long quantity;
    protected RateType rateType;
    protected StockItemDTO stockItemDTO;

    /**
     * Gets the value of the maximumPurchaseAmount property.
     * 
     */
    public double getMaximumPurchaseAmount() {
        return maximumPurchaseAmount;
    }

    /**
     * Sets the value of the maximumPurchaseAmount property.
     * 
     */
    public void setMaximumPurchaseAmount(double value) {
        this.maximumPurchaseAmount = value;
    }

    /**
     * Gets the value of the minimumPurchaseAmount property.
     * 
     */
    public double getMinimumPurchaseAmount() {
        return minimumPurchaseAmount;
    }

    /**
     * Sets the value of the minimumPurchaseAmount property.
     * 
     */
    public void setMinimumPurchaseAmount(double value) {
        this.minimumPurchaseAmount = value;
    }

    /**
     * Gets the value of the numberOfPoints property.
     * 
     */
    public int getNumberOfPoints() {
        return numberOfPoints;
    }

    /**
     * Sets the value of the numberOfPoints property.
     * 
     */
    public void setNumberOfPoints(int value) {
        this.numberOfPoints = value;
    }

    /**
     * Gets the value of the promotionAmount property.
     * 
     */
    public double getPromotionAmount() {
        return promotionAmount;
    }

    /**
     * Sets the value of the promotionAmount property.
     * 
     */
    public void setPromotionAmount(double value) {
        this.promotionAmount = value;
    }

    /**
     * Gets the value of the promotionID property.
     * 
     */
    public long getPromotionID() {
        return promotionID;
    }

    /**
     * Sets the value of the promotionID property.
     * 
     */
    public void setPromotionID(long value) {
        this.promotionID = value;
    }

    /**
     * Gets the value of the promotionRewardID property.
     * 
     */
    public long getPromotionRewardID() {
        return promotionRewardID;
    }

    /**
     * Sets the value of the promotionRewardID property.
     * 
     */
    public void setPromotionRewardID(long value) {
        this.promotionRewardID = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     */
    public long getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     */
    public void setQuantity(long value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the rateType property.
     * 
     * @return
     *     possible object is
     *     {@link RateType }
     *     
     */
    public RateType getRateType() {
        return rateType;
    }

    /**
     * Sets the value of the rateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RateType }
     *     
     */
    public void setRateType(RateType value) {
        this.rateType = value;
    }

    /**
     * Gets the value of the stockItemDTO property.
     * 
     * @return
     *     possible object is
     *     {@link StockItemDTO }
     *     
     */
    public StockItemDTO getStockItemDTO() {
        return stockItemDTO;
    }

    /**
     * Sets the value of the stockItemDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link StockItemDTO }
     *     
     */
    public void setStockItemDTO(StockItemDTO value) {
        this.stockItemDTO = value;
    }

}
