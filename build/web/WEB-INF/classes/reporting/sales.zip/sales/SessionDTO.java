
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for sessionDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sessionDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="password" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="posSessionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="posSessionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sesionStartTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sessionEndTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="suspended" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="total" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalBalance" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalCard" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalCash" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalLoyalty" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalRefund" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="userId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sessionDTO", propOrder = {
    "password",
    "posSessionID",
    "posSessionName",
    "sesionStartTime",
    "sessionEndTime",
    "state",
    "suspended",
    "total",
    "totalBalance",
    "totalCard",
    "totalCash",
    "totalLoyalty",
    "totalRefund",
    "userId",
    "userName"
})
public class SessionDTO {

    protected String password;
    protected long posSessionID;
    protected String posSessionName;
    protected String sesionStartTime;
    protected String sessionEndTime;
    protected String state;
    protected boolean suspended;
    protected double total;
    protected double totalBalance;
    protected double totalCard;
    protected double totalCash;
    protected double totalLoyalty;
    protected double totalRefund;
    protected long userId;
    protected String userName;

    /**
     * Gets the value of the password property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassword(String value) {
        this.password = value;
    }

    /**
     * Gets the value of the posSessionID property.
     * 
     */
    public long getPosSessionID() {
        return posSessionID;
    }

    /**
     * Sets the value of the posSessionID property.
     * 
     */
    public void setPosSessionID(long value) {
        this.posSessionID = value;
    }

    /**
     * Gets the value of the posSessionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPosSessionName() {
        return posSessionName;
    }

    /**
     * Sets the value of the posSessionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPosSessionName(String value) {
        this.posSessionName = value;
    }

    /**
     * Gets the value of the sesionStartTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSesionStartTime() {
        return sesionStartTime;
    }

    /**
     * Sets the value of the sesionStartTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSesionStartTime(String value) {
        this.sesionStartTime = value;
    }

    /**
     * Gets the value of the sessionEndTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionEndTime() {
        return sessionEndTime;
    }

    /**
     * Sets the value of the sessionEndTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionEndTime(String value) {
        this.sessionEndTime = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the suspended property.
     * 
     */
    public boolean isSuspended() {
        return suspended;
    }

    /**
     * Sets the value of the suspended property.
     * 
     */
    public void setSuspended(boolean value) {
        this.suspended = value;
    }

    /**
     * Gets the value of the total property.
     * 
     */
    public double getTotal() {
        return total;
    }

    /**
     * Sets the value of the total property.
     * 
     */
    public void setTotal(double value) {
        this.total = value;
    }

    /**
     * Gets the value of the totalBalance property.
     * 
     */
    public double getTotalBalance() {
        return totalBalance;
    }

    /**
     * Sets the value of the totalBalance property.
     * 
     */
    public void setTotalBalance(double value) {
        this.totalBalance = value;
    }

    /**
     * Gets the value of the totalCard property.
     * 
     */
    public double getTotalCard() {
        return totalCard;
    }

    /**
     * Sets the value of the totalCard property.
     * 
     */
    public void setTotalCard(double value) {
        this.totalCard = value;
    }

    /**
     * Gets the value of the totalCash property.
     * 
     */
    public double getTotalCash() {
        return totalCash;
    }

    /**
     * Sets the value of the totalCash property.
     * 
     */
    public void setTotalCash(double value) {
        this.totalCash = value;
    }

    /**
     * Gets the value of the totalLoyalty property.
     * 
     */
    public double getTotalLoyalty() {
        return totalLoyalty;
    }

    /**
     * Sets the value of the totalLoyalty property.
     * 
     */
    public void setTotalLoyalty(double value) {
        this.totalLoyalty = value;
    }

    /**
     * Gets the value of the totalRefund property.
     * 
     */
    public double getTotalRefund() {
        return totalRefund;
    }

    /**
     * Sets the value of the totalRefund property.
     * 
     */
    public void setTotalRefund(double value) {
        this.totalRefund = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     */
    public long getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     */
    public void setUserId(long value) {
        this.userId = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

}
