
package com.s3systems.remote.sales;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for salesPromotionDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="salesPromotionDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="endDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="numberOfUses" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="promoIdentificationType" type="{http://services.endpoint.business.rsdynamix.com/}promoIdentificationType" minOccurs="0"/>
 *         &lt;element name="promotionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="promotionCodes" type="{http://services.endpoint.business.rsdynamix.com/}promotionCodeDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="promotionDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="promotionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="promotionRewardList" type="{http://services.endpoint.business.rsdynamix.com/}promotionRewardDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="promotionTypeID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="promotionTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="stockItemID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="stockItemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="validityStatus" type="{http://services.endpoint.business.rsdynamix.com/}statusType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "salesPromotionDTO", propOrder = {
    "endDate",
    "numberOfUses",
    "promoIdentificationType",
    "promotionCode",
    "promotionCodes",
    "promotionDesc",
    "promotionID",
    "promotionRewardList",
    "promotionTypeID",
    "promotionTypeName",
    "startDate",
    "stockItemID",
    "stockItemName",
    "validityStatus"
})
public class SalesPromotionDTO {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar endDate;
    protected int numberOfUses;
    protected PromoIdentificationType promoIdentificationType;
    protected String promotionCode;
    @XmlElement(nillable = true)
    protected List<PromotionCodeDTO> promotionCodes;
    protected String promotionDesc;
    protected long promotionID;
    @XmlElement(nillable = true)
    protected List<PromotionRewardDTO> promotionRewardList;
    protected int promotionTypeID;
    protected String promotionTypeName;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar startDate;
    protected long stockItemID;
    protected String stockItemName;
    protected StatusType validityStatus;

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEndDate(XMLGregorianCalendar value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the numberOfUses property.
     * 
     */
    public int getNumberOfUses() {
        return numberOfUses;
    }

    /**
     * Sets the value of the numberOfUses property.
     * 
     */
    public void setNumberOfUses(int value) {
        this.numberOfUses = value;
    }

    /**
     * Gets the value of the promoIdentificationType property.
     * 
     * @return
     *     possible object is
     *     {@link PromoIdentificationType }
     *     
     */
    public PromoIdentificationType getPromoIdentificationType() {
        return promoIdentificationType;
    }

    /**
     * Sets the value of the promoIdentificationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PromoIdentificationType }
     *     
     */
    public void setPromoIdentificationType(PromoIdentificationType value) {
        this.promoIdentificationType = value;
    }

    /**
     * Gets the value of the promotionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCode() {
        return promotionCode;
    }

    /**
     * Sets the value of the promotionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCode(String value) {
        this.promotionCode = value;
    }

    /**
     * Gets the value of the promotionCodes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the promotionCodes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPromotionCodes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PromotionCodeDTO }
     * 
     * 
     */
    public List<PromotionCodeDTO> getPromotionCodes() {
        if (promotionCodes == null) {
            promotionCodes = new ArrayList<PromotionCodeDTO>();
        }
        return this.promotionCodes;
    }

    /**
     * Gets the value of the promotionDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionDesc() {
        return promotionDesc;
    }

    /**
     * Sets the value of the promotionDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionDesc(String value) {
        this.promotionDesc = value;
    }

    /**
     * Gets the value of the promotionID property.
     * 
     */
    public long getPromotionID() {
        return promotionID;
    }

    /**
     * Sets the value of the promotionID property.
     * 
     */
    public void setPromotionID(long value) {
        this.promotionID = value;
    }

    /**
     * Gets the value of the promotionRewardList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the promotionRewardList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPromotionRewardList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PromotionRewardDTO }
     * 
     * 
     */
    public List<PromotionRewardDTO> getPromotionRewardList() {
        if (promotionRewardList == null) {
            promotionRewardList = new ArrayList<PromotionRewardDTO>();
        }
        return this.promotionRewardList;
    }

    /**
     * Gets the value of the promotionTypeID property.
     * 
     */
    public int getPromotionTypeID() {
        return promotionTypeID;
    }

    /**
     * Sets the value of the promotionTypeID property.
     * 
     */
    public void setPromotionTypeID(int value) {
        this.promotionTypeID = value;
    }

    /**
     * Gets the value of the promotionTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionTypeName() {
        return promotionTypeName;
    }

    /**
     * Sets the value of the promotionTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionTypeName(String value) {
        this.promotionTypeName = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the stockItemID property.
     * 
     */
    public long getStockItemID() {
        return stockItemID;
    }

    /**
     * Sets the value of the stockItemID property.
     * 
     */
    public void setStockItemID(long value) {
        this.stockItemID = value;
    }

    /**
     * Gets the value of the stockItemName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockItemName() {
        return stockItemName;
    }

    /**
     * Sets the value of the stockItemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockItemName(String value) {
        this.stockItemName = value;
    }

    /**
     * Gets the value of the validityStatus property.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusType getValidityStatus() {
        return validityStatus;
    }

    /**
     * Sets the value of the validityStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setValidityStatus(StatusType value) {
        this.validityStatus = value;
    }

}
