
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for paymentFrequencyType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="paymentFrequencyType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NONE"/>
 *     &lt;enumeration value="DAILY"/>
 *     &lt;enumeration value="WEEKLY"/>
 *     &lt;enumeration value="MONTHLY"/>
 *     &lt;enumeration value="BI_MONTHLY"/>
 *     &lt;enumeration value="QUARTERLY"/>
 *     &lt;enumeration value="SEMI_ANNUALLY"/>
 *     &lt;enumeration value="ANNUALLY"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "paymentFrequencyType")
@XmlEnum
public enum PaymentFrequencyType {

    NONE,
    DAILY,
    WEEKLY,
    MONTHLY,
    BI_MONTHLY,
    QUARTERLY,
    SEMI_ANNUALLY,
    ANNUALLY;

    public String value() {
        return name();
    }

    public static PaymentFrequencyType fromValue(String v) {
        return valueOf(v);
    }

}
