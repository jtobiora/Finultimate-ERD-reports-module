
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for promoIdentificationType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="promoIdentificationType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NONE"/>
 *     &lt;enumeration value="NOTHING_REQUIRED"/>
 *     &lt;enumeration value="CODE_REQUIRED"/>
 *     &lt;enumeration value="KYC_REQUIRED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "promoIdentificationType")
@XmlEnum
public enum PromoIdentificationType {

    NONE,
    NOTHING_REQUIRED,
    CODE_REQUIRED,
    KYC_REQUIRED;

    public String value() {
        return name();
    }

    public static PromoIdentificationType fromValue(String v) {
        return valueOf(v);
    }

}
