
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for stockActiveIngredientDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="stockActiveIngredientDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ingredientID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ingredientName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stockIngredientID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="stockItemID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stockActiveIngredientDTO", propOrder = {
    "ingredientID",
    "ingredientName",
    "itemName",
    "stockIngredientID",
    "stockItemID"
})
public class StockActiveIngredientDTO {

    protected long ingredientID;
    protected String ingredientName;
    protected String itemName;
    protected long stockIngredientID;
    protected long stockItemID;

    /**
     * Gets the value of the ingredientID property.
     * 
     */
    public long getIngredientID() {
        return ingredientID;
    }

    /**
     * Sets the value of the ingredientID property.
     * 
     */
    public void setIngredientID(long value) {
        this.ingredientID = value;
    }

    /**
     * Gets the value of the ingredientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIngredientName() {
        return ingredientName;
    }

    /**
     * Sets the value of the ingredientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIngredientName(String value) {
        this.ingredientName = value;
    }

    /**
     * Gets the value of the itemName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * Sets the value of the itemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemName(String value) {
        this.itemName = value;
    }

    /**
     * Gets the value of the stockIngredientID property.
     * 
     */
    public long getStockIngredientID() {
        return stockIngredientID;
    }

    /**
     * Sets the value of the stockIngredientID property.
     * 
     */
    public void setStockIngredientID(long value) {
        this.stockIngredientID = value;
    }

    /**
     * Gets the value of the stockItemID property.
     * 
     */
    public long getStockItemID() {
        return stockItemID;
    }

    /**
     * Sets the value of the stockItemID property.
     * 
     */
    public void setStockItemID(long value) {
        this.stockItemID = value;
    }

}
