
package com.s3systems.remote.sales;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for stockItemDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="stockItemDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="approvalStatusID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="availabilityIndicationColor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="averagePurchasePrice" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="barcodeNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="categoryDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="companyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contraIndication" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="imageContent" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="imageFileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemCategoryID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="itemDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemTypeID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="lastUpdate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="manufacturerID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="manufacturerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="maximumValue" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="miscellaneousAttribList" type="{http://services.endpoint.business.rsdynamix.com/}miscAttributeDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="numberOfItems" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="promotions" type="{http://services.endpoint.business.rsdynamix.com/}salesPromotionDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="quantity" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="reorderLevel" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="sectionDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sectionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="selectItemCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="selectedForWarehouse" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="shelfDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shelfID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="stockActiveIngredientList" type="{http://services.endpoint.business.rsdynamix.com/}stockActiveIngredientDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="stockItemCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stockItemID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="stockItemVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stockRelationList" type="{http://services.endpoint.business.rsdynamix.com/}stockRelationDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="totalPurchasePrice" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalSellingPrice" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="unitMeasure" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="unitOfMeasureID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="unitOfMeasureShort" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unitPrice" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="unitTypeID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="unitTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="warehouseDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="warehouseID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stockItemDTO", propOrder = {
    "approvalStatusID",
    "availabilityIndicationColor",
    "averagePurchasePrice",
    "barcodeNumber",
    "categoryDesc",
    "companyName",
    "contraIndication",
    "currencyCode",
    "imageContent",
    "imageFileName",
    "itemCategoryID",
    "itemDescription",
    "itemName",
    "itemTypeDesc",
    "itemTypeID",
    "lastUpdate",
    "manufacturerID",
    "manufacturerName",
    "maximumValue",
    "miscellaneousAttribList",
    "numberOfItems",
    "promotions",
    "quantity",
    "reorderLevel",
    "sectionDesc",
    "sectionID",
    "selectItemCount",
    "selectedForWarehouse",
    "shelfDesc",
    "shelfID",
    "stockActiveIngredientList",
    "stockItemCode",
    "stockItemID",
    "stockItemVersion",
    "stockRelationList",
    "totalPurchasePrice",
    "totalSellingPrice",
    "unitMeasure",
    "unitOfMeasureID",
    "unitOfMeasureShort",
    "unitPrice",
    "unitTypeID",
    "unitTypeName",
    "warehouseDesc",
    "warehouseID"
})
public class StockItemDTO {

    protected int approvalStatusID;
    protected String availabilityIndicationColor;
    protected double averagePurchasePrice;
    protected String barcodeNumber;
    protected String categoryDesc;
    protected String companyName;
    protected String contraIndication;
    protected String currencyCode;
    protected byte[] imageContent;
    protected String imageFileName;
    protected long itemCategoryID;
    protected String itemDescription;
    protected String itemName;
    protected String itemTypeDesc;
    protected long itemTypeID;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdate;
    protected int manufacturerID;
    protected String manufacturerName;
    protected long maximumValue;
    @XmlElement(nillable = true)
    protected List<MiscAttributeDTO> miscellaneousAttribList;
    protected int numberOfItems;
    @XmlElement(nillable = true)
    protected List<SalesPromotionDTO> promotions;
    protected double quantity;
    protected long reorderLevel;
    protected String sectionDesc;
    protected long sectionID;
    protected long selectItemCount;
    protected boolean selectedForWarehouse;
    protected String shelfDesc;
    protected long shelfID;
    @XmlElement(nillable = true)
    protected List<StockActiveIngredientDTO> stockActiveIngredientList;
    protected String stockItemCode;
    protected long stockItemID;
    protected String stockItemVersion;
    @XmlElement(nillable = true)
    protected List<StockRelationDTO> stockRelationList;
    protected double totalPurchasePrice;
    protected double totalSellingPrice;
    protected double unitMeasure;
    protected long unitOfMeasureID;
    protected String unitOfMeasureShort;
    protected double unitPrice;
    protected int unitTypeID;
    protected String unitTypeName;
    protected String warehouseDesc;
    protected long warehouseID;

    /**
     * Gets the value of the approvalStatusID property.
     * 
     */
    public int getApprovalStatusID() {
        return approvalStatusID;
    }

    /**
     * Sets the value of the approvalStatusID property.
     * 
     */
    public void setApprovalStatusID(int value) {
        this.approvalStatusID = value;
    }

    /**
     * Gets the value of the availabilityIndicationColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvailabilityIndicationColor() {
        return availabilityIndicationColor;
    }

    /**
     * Sets the value of the availabilityIndicationColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvailabilityIndicationColor(String value) {
        this.availabilityIndicationColor = value;
    }

    /**
     * Gets the value of the averagePurchasePrice property.
     * 
     */
    public double getAveragePurchasePrice() {
        return averagePurchasePrice;
    }

    /**
     * Sets the value of the averagePurchasePrice property.
     * 
     */
    public void setAveragePurchasePrice(double value) {
        this.averagePurchasePrice = value;
    }

    /**
     * Gets the value of the barcodeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBarcodeNumber() {
        return barcodeNumber;
    }

    /**
     * Sets the value of the barcodeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBarcodeNumber(String value) {
        this.barcodeNumber = value;
    }

    /**
     * Gets the value of the categoryDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategoryDesc() {
        return categoryDesc;
    }

    /**
     * Sets the value of the categoryDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategoryDesc(String value) {
        this.categoryDesc = value;
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyName(String value) {
        this.companyName = value;
    }

    /**
     * Gets the value of the contraIndication property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContraIndication() {
        return contraIndication;
    }

    /**
     * Sets the value of the contraIndication property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContraIndication(String value) {
        this.contraIndication = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the imageContent property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getImageContent() {
        return imageContent;
    }

    /**
     * Sets the value of the imageContent property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setImageContent(byte[] value) {
        this.imageContent = value;
    }

    /**
     * Gets the value of the imageFileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImageFileName() {
        return imageFileName;
    }

    /**
     * Sets the value of the imageFileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImageFileName(String value) {
        this.imageFileName = value;
    }

    /**
     * Gets the value of the itemCategoryID property.
     * 
     */
    public long getItemCategoryID() {
        return itemCategoryID;
    }

    /**
     * Sets the value of the itemCategoryID property.
     * 
     */
    public void setItemCategoryID(long value) {
        this.itemCategoryID = value;
    }

    /**
     * Gets the value of the itemDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /**
     * Sets the value of the itemDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemDescription(String value) {
        this.itemDescription = value;
    }

    /**
     * Gets the value of the itemName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * Sets the value of the itemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemName(String value) {
        this.itemName = value;
    }

    /**
     * Gets the value of the itemTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemTypeDesc() {
        return itemTypeDesc;
    }

    /**
     * Sets the value of the itemTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemTypeDesc(String value) {
        this.itemTypeDesc = value;
    }

    /**
     * Gets the value of the itemTypeID property.
     * 
     */
    public long getItemTypeID() {
        return itemTypeID;
    }

    /**
     * Sets the value of the itemTypeID property.
     * 
     */
    public void setItemTypeID(long value) {
        this.itemTypeID = value;
    }

    /**
     * Gets the value of the lastUpdate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdate() {
        return lastUpdate;
    }

    /**
     * Sets the value of the lastUpdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdate(XMLGregorianCalendar value) {
        this.lastUpdate = value;
    }

    /**
     * Gets the value of the manufacturerID property.
     * 
     */
    public int getManufacturerID() {
        return manufacturerID;
    }

    /**
     * Sets the value of the manufacturerID property.
     * 
     */
    public void setManufacturerID(int value) {
        this.manufacturerID = value;
    }

    /**
     * Gets the value of the manufacturerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManufacturerName() {
        return manufacturerName;
    }

    /**
     * Sets the value of the manufacturerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManufacturerName(String value) {
        this.manufacturerName = value;
    }

    /**
     * Gets the value of the maximumValue property.
     * 
     */
    public long getMaximumValue() {
        return maximumValue;
    }

    /**
     * Sets the value of the maximumValue property.
     * 
     */
    public void setMaximumValue(long value) {
        this.maximumValue = value;
    }

    /**
     * Gets the value of the miscellaneousAttribList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miscellaneousAttribList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiscellaneousAttribList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MiscAttributeDTO }
     * 
     * 
     */
    public List<MiscAttributeDTO> getMiscellaneousAttribList() {
        if (miscellaneousAttribList == null) {
            miscellaneousAttribList = new ArrayList<MiscAttributeDTO>();
        }
        return this.miscellaneousAttribList;
    }

    /**
     * Gets the value of the numberOfItems property.
     * 
     */
    public int getNumberOfItems() {
        return numberOfItems;
    }

    /**
     * Sets the value of the numberOfItems property.
     * 
     */
    public void setNumberOfItems(int value) {
        this.numberOfItems = value;
    }

    /**
     * Gets the value of the promotions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the promotions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPromotions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SalesPromotionDTO }
     * 
     * 
     */
    public List<SalesPromotionDTO> getPromotions() {
        if (promotions == null) {
            promotions = new ArrayList<SalesPromotionDTO>();
        }
        return this.promotions;
    }

    /**
     * Gets the value of the quantity property.
     * 
     */
    public double getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     */
    public void setQuantity(double value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the reorderLevel property.
     * 
     */
    public long getReorderLevel() {
        return reorderLevel;
    }

    /**
     * Sets the value of the reorderLevel property.
     * 
     */
    public void setReorderLevel(long value) {
        this.reorderLevel = value;
    }

    /**
     * Gets the value of the sectionDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSectionDesc() {
        return sectionDesc;
    }

    /**
     * Sets the value of the sectionDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSectionDesc(String value) {
        this.sectionDesc = value;
    }

    /**
     * Gets the value of the sectionID property.
     * 
     */
    public long getSectionID() {
        return sectionID;
    }

    /**
     * Sets the value of the sectionID property.
     * 
     */
    public void setSectionID(long value) {
        this.sectionID = value;
    }

    /**
     * Gets the value of the selectItemCount property.
     * 
     */
    public long getSelectItemCount() {
        return selectItemCount;
    }

    /**
     * Sets the value of the selectItemCount property.
     * 
     */
    public void setSelectItemCount(long value) {
        this.selectItemCount = value;
    }

    /**
     * Gets the value of the selectedForWarehouse property.
     * 
     */
    public boolean isSelectedForWarehouse() {
        return selectedForWarehouse;
    }

    /**
     * Sets the value of the selectedForWarehouse property.
     * 
     */
    public void setSelectedForWarehouse(boolean value) {
        this.selectedForWarehouse = value;
    }

    /**
     * Gets the value of the shelfDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShelfDesc() {
        return shelfDesc;
    }

    /**
     * Sets the value of the shelfDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShelfDesc(String value) {
        this.shelfDesc = value;
    }

    /**
     * Gets the value of the shelfID property.
     * 
     */
    public long getShelfID() {
        return shelfID;
    }

    /**
     * Sets the value of the shelfID property.
     * 
     */
    public void setShelfID(long value) {
        this.shelfID = value;
    }

    /**
     * Gets the value of the stockActiveIngredientList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stockActiveIngredientList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStockActiveIngredientList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StockActiveIngredientDTO }
     * 
     * 
     */
    public List<StockActiveIngredientDTO> getStockActiveIngredientList() {
        if (stockActiveIngredientList == null) {
            stockActiveIngredientList = new ArrayList<StockActiveIngredientDTO>();
        }
        return this.stockActiveIngredientList;
    }

    /**
     * Gets the value of the stockItemCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockItemCode() {
        return stockItemCode;
    }

    /**
     * Sets the value of the stockItemCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockItemCode(String value) {
        this.stockItemCode = value;
    }

    /**
     * Gets the value of the stockItemID property.
     * 
     */
    public long getStockItemID() {
        return stockItemID;
    }

    /**
     * Sets the value of the stockItemID property.
     * 
     */
    public void setStockItemID(long value) {
        this.stockItemID = value;
    }

    /**
     * Gets the value of the stockItemVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockItemVersion() {
        return stockItemVersion;
    }

    /**
     * Sets the value of the stockItemVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockItemVersion(String value) {
        this.stockItemVersion = value;
    }

    /**
     * Gets the value of the stockRelationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stockRelationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStockRelationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StockRelationDTO }
     * 
     * 
     */
    public List<StockRelationDTO> getStockRelationList() {
        if (stockRelationList == null) {
            stockRelationList = new ArrayList<StockRelationDTO>();
        }
        return this.stockRelationList;
    }

    /**
     * Gets the value of the totalPurchasePrice property.
     * 
     */
    public double getTotalPurchasePrice() {
        return totalPurchasePrice;
    }

    /**
     * Sets the value of the totalPurchasePrice property.
     * 
     */
    public void setTotalPurchasePrice(double value) {
        this.totalPurchasePrice = value;
    }

    /**
     * Gets the value of the totalSellingPrice property.
     * 
     */
    public double getTotalSellingPrice() {
        return totalSellingPrice;
    }

    /**
     * Sets the value of the totalSellingPrice property.
     * 
     */
    public void setTotalSellingPrice(double value) {
        this.totalSellingPrice = value;
    }

    /**
     * Gets the value of the unitMeasure property.
     * 
     */
    public double getUnitMeasure() {
        return unitMeasure;
    }

    /**
     * Sets the value of the unitMeasure property.
     * 
     */
    public void setUnitMeasure(double value) {
        this.unitMeasure = value;
    }

    /**
     * Gets the value of the unitOfMeasureID property.
     * 
     */
    public long getUnitOfMeasureID() {
        return unitOfMeasureID;
    }

    /**
     * Sets the value of the unitOfMeasureID property.
     * 
     */
    public void setUnitOfMeasureID(long value) {
        this.unitOfMeasureID = value;
    }

    /**
     * Gets the value of the unitOfMeasureShort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitOfMeasureShort() {
        return unitOfMeasureShort;
    }

    /**
     * Sets the value of the unitOfMeasureShort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitOfMeasureShort(String value) {
        this.unitOfMeasureShort = value;
    }

    /**
     * Gets the value of the unitPrice property.
     * 
     */
    public double getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the value of the unitPrice property.
     * 
     */
    public void setUnitPrice(double value) {
        this.unitPrice = value;
    }

    /**
     * Gets the value of the unitTypeID property.
     * 
     */
    public int getUnitTypeID() {
        return unitTypeID;
    }

    /**
     * Sets the value of the unitTypeID property.
     * 
     */
    public void setUnitTypeID(int value) {
        this.unitTypeID = value;
    }

    /**
     * Gets the value of the unitTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitTypeName() {
        return unitTypeName;
    }

    /**
     * Sets the value of the unitTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitTypeName(String value) {
        this.unitTypeName = value;
    }

    /**
     * Gets the value of the warehouseDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWarehouseDesc() {
        return warehouseDesc;
    }

    /**
     * Sets the value of the warehouseDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWarehouseDesc(String value) {
        this.warehouseDesc = value;
    }

    /**
     * Gets the value of the warehouseID property.
     * 
     */
    public long getWarehouseID() {
        return warehouseID;
    }

    /**
     * Sets the value of the warehouseID property.
     * 
     */
    public void setWarehouseID(long value) {
        this.warehouseID = value;
    }

}
