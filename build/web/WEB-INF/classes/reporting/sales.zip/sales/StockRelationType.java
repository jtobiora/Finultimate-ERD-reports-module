
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for stockRelationType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="stockRelationType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NONE"/>
 *     &lt;enumeration value="ACCESSORY"/>
 *     &lt;enumeration value="MATCH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "stockRelationType")
@XmlEnum
public enum StockRelationType {

    NONE,
    ACCESSORY,
    MATCH;

    public String value() {
        return name();
    }

    public static StockRelationType fromValue(String v) {
        return valueOf(v);
    }

}
