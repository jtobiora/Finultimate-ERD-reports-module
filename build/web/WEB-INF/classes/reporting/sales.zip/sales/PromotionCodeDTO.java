
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for promotionCodeDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="promotionCodeDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="promotionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="promotionDTO" type="{http://services.endpoint.business.rsdynamix.com/}salesPromotionDTO" minOccurs="0"/>
 *         &lt;element name="status" type="{http://services.endpoint.business.rsdynamix.com/}statusType" minOccurs="0"/>
 *         &lt;element name="useCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "promotionCodeDTO", propOrder = {
    "id",
    "promotionCode",
    "promotionDTO",
    "status",
    "useCount"
})
public class PromotionCodeDTO {

    protected long id;
    protected String promotionCode;
    protected SalesPromotionDTO promotionDTO;
    protected StatusType status;
    protected long useCount;

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the promotionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCode() {
        return promotionCode;
    }

    /**
     * Sets the value of the promotionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCode(String value) {
        this.promotionCode = value;
    }

    /**
     * Gets the value of the promotionDTO property.
     * 
     * @return
     *     possible object is
     *     {@link SalesPromotionDTO }
     *     
     */
    public SalesPromotionDTO getPromotionDTO() {
        return promotionDTO;
    }

    /**
     * Sets the value of the promotionDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link SalesPromotionDTO }
     *     
     */
    public void setPromotionDTO(SalesPromotionDTO value) {
        this.promotionDTO = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setStatus(StatusType value) {
        this.status = value;
    }

    /**
     * Gets the value of the useCount property.
     * 
     */
    public long getUseCount() {
        return useCount;
    }

    /**
     * Sets the value of the useCount property.
     * 
     */
    public void setUseCount(long value) {
        this.useCount = value;
    }

}
