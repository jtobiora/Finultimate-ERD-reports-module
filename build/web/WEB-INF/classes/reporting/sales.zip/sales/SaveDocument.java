
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for saveDocument complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="saveDocument">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userAccount" type="{http://services.endpoint.business.rsdynamix.com/}userAccountDTO" minOccurs="0"/>
 *         &lt;element name="documentDTO" type="{http://services.endpoint.business.rsdynamix.com/}documentDTO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "saveDocument", propOrder = {
    "userAccount",
    "documentDTO"
})
public class SaveDocument {

    protected UserAccountDTO userAccount;
    protected DocumentDTO documentDTO;

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountDTO }
     *     
     */
    public UserAccountDTO getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountDTO }
     *     
     */
    public void setUserAccount(UserAccountDTO value) {
        this.userAccount = value;
    }

    /**
     * Gets the value of the documentDTO property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentDTO }
     *     
     */
    public DocumentDTO getDocumentDTO() {
        return documentDTO;
    }

    /**
     * Sets the value of the documentDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentDTO }
     *     
     */
    public void setDocumentDTO(DocumentDTO value) {
        this.documentDTO = value;
    }

}
