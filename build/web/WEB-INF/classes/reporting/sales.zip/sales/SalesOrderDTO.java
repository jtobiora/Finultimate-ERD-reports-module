
package com.s3systems.remote.sales;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for salesOrderDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="salesOrderDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="amountFromLoyaltyPoints" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="clientCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="clientName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="frequencyType" type="{http://services.endpoint.business.rsdynamix.com/}paymentFrequencyType" minOccurs="0"/>
 *         &lt;element name="instalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="instalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="layaltyPoints" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="mobileNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="orderDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="orderNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="orderTotal" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="promotionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="salesOrderID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="salesOrderItemList" type="{http://services.endpoint.business.rsdynamix.com/}salesOrderItemDTO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="totalCostOfSales" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalDiscount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalLayaltyAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="totalLayaltyPoints" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="transactOrderTotal" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="transactionEarningType" type="{http://services.endpoint.business.rsdynamix.com/}transactionEarningType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "salesOrderDTO", propOrder = {
    "amountFromLoyaltyPoints",
    "clientCode",
    "clientName",
    "currencyCode",
    "emailAddress",
    "frequencyType",
    "instalmentEndDate",
    "instalmentStartDate",
    "layaltyPoints",
    "mobileNumber",
    "orderDate",
    "orderNumber",
    "orderTotal",
    "promotionCode",
    "salesOrderID",
    "salesOrderItemList",
    "totalCostOfSales",
    "totalDiscount",
    "totalLayaltyAmount",
    "totalLayaltyPoints",
    "transactOrderTotal",
    "transactionEarningType"
})
public class SalesOrderDTO {

    protected double amountFromLoyaltyPoints;
    protected String clientCode;
    protected String clientName;
    protected String currencyCode;
    protected String emailAddress;
    protected PaymentFrequencyType frequencyType;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar instalmentEndDate;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar instalmentStartDate;
    protected int layaltyPoints;
    protected String mobileNumber;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar orderDate;
    protected String orderNumber;
    protected double orderTotal;
    protected String promotionCode;
    protected long salesOrderID;
    @XmlElement(nillable = true)
    protected List<SalesOrderItemDTO> salesOrderItemList;
    protected double totalCostOfSales;
    protected double totalDiscount;
    protected double totalLayaltyAmount;
    protected double totalLayaltyPoints;
    protected double transactOrderTotal;
    protected TransactionEarningType transactionEarningType;

    /**
     * Gets the value of the amountFromLoyaltyPoints property.
     * 
     */
    public double getAmountFromLoyaltyPoints() {
        return amountFromLoyaltyPoints;
    }

    /**
     * Sets the value of the amountFromLoyaltyPoints property.
     * 
     */
    public void setAmountFromLoyaltyPoints(double value) {
        this.amountFromLoyaltyPoints = value;
    }

    /**
     * Gets the value of the clientCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientCode() {
        return clientCode;
    }

    /**
     * Sets the value of the clientCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientCode(String value) {
        this.clientCode = value;
    }

    /**
     * Gets the value of the clientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the value of the clientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientName(String value) {
        this.clientName = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the frequencyType property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentFrequencyType }
     *     
     */
    public PaymentFrequencyType getFrequencyType() {
        return frequencyType;
    }

    /**
     * Sets the value of the frequencyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentFrequencyType }
     *     
     */
    public void setFrequencyType(PaymentFrequencyType value) {
        this.frequencyType = value;
    }

    /**
     * Gets the value of the instalmentEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getInstalmentEndDate() {
        return instalmentEndDate;
    }

    /**
     * Sets the value of the instalmentEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setInstalmentEndDate(XMLGregorianCalendar value) {
        this.instalmentEndDate = value;
    }

    /**
     * Gets the value of the instalmentStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getInstalmentStartDate() {
        return instalmentStartDate;
    }

    /**
     * Sets the value of the instalmentStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setInstalmentStartDate(XMLGregorianCalendar value) {
        this.instalmentStartDate = value;
    }

    /**
     * Gets the value of the layaltyPoints property.
     * 
     */
    public int getLayaltyPoints() {
        return layaltyPoints;
    }

    /**
     * Sets the value of the layaltyPoints property.
     * 
     */
    public void setLayaltyPoints(int value) {
        this.layaltyPoints = value;
    }

    /**
     * Gets the value of the mobileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Sets the value of the mobileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNumber(String value) {
        this.mobileNumber = value;
    }

    /**
     * Gets the value of the orderDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the value of the orderDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOrderDate(XMLGregorianCalendar value) {
        this.orderDate = value;
    }

    /**
     * Gets the value of the orderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     * Sets the value of the orderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderNumber(String value) {
        this.orderNumber = value;
    }

    /**
     * Gets the value of the orderTotal property.
     * 
     */
    public double getOrderTotal() {
        return orderTotal;
    }

    /**
     * Sets the value of the orderTotal property.
     * 
     */
    public void setOrderTotal(double value) {
        this.orderTotal = value;
    }

    /**
     * Gets the value of the promotionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCode() {
        return promotionCode;
    }

    /**
     * Sets the value of the promotionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCode(String value) {
        this.promotionCode = value;
    }

    /**
     * Gets the value of the salesOrderID property.
     * 
     */
    public long getSalesOrderID() {
        return salesOrderID;
    }

    /**
     * Sets the value of the salesOrderID property.
     * 
     */
    public void setSalesOrderID(long value) {
        this.salesOrderID = value;
    }

    /**
     * Gets the value of the salesOrderItemList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the salesOrderItemList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSalesOrderItemList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SalesOrderItemDTO }
     * 
     * 
     */
    public List<SalesOrderItemDTO> getSalesOrderItemList() {
        if (salesOrderItemList == null) {
            salesOrderItemList = new ArrayList<SalesOrderItemDTO>();
        }
        return this.salesOrderItemList;
    }

    /**
     * Gets the value of the totalCostOfSales property.
     * 
     */
    public double getTotalCostOfSales() {
        return totalCostOfSales;
    }

    /**
     * Sets the value of the totalCostOfSales property.
     * 
     */
    public void setTotalCostOfSales(double value) {
        this.totalCostOfSales = value;
    }

    /**
     * Gets the value of the totalDiscount property.
     * 
     */
    public double getTotalDiscount() {
        return totalDiscount;
    }

    /**
     * Sets the value of the totalDiscount property.
     * 
     */
    public void setTotalDiscount(double value) {
        this.totalDiscount = value;
    }

    /**
     * Gets the value of the totalLayaltyAmount property.
     * 
     */
    public double getTotalLayaltyAmount() {
        return totalLayaltyAmount;
    }

    /**
     * Sets the value of the totalLayaltyAmount property.
     * 
     */
    public void setTotalLayaltyAmount(double value) {
        this.totalLayaltyAmount = value;
    }

    /**
     * Gets the value of the totalLayaltyPoints property.
     * 
     */
    public double getTotalLayaltyPoints() {
        return totalLayaltyPoints;
    }

    /**
     * Sets the value of the totalLayaltyPoints property.
     * 
     */
    public void setTotalLayaltyPoints(double value) {
        this.totalLayaltyPoints = value;
    }

    /**
     * Gets the value of the transactOrderTotal property.
     * 
     */
    public double getTransactOrderTotal() {
        return transactOrderTotal;
    }

    /**
     * Sets the value of the transactOrderTotal property.
     * 
     */
    public void setTransactOrderTotal(double value) {
        this.transactOrderTotal = value;
    }

    /**
     * Gets the value of the transactionEarningType property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionEarningType }
     *     
     */
    public TransactionEarningType getTransactionEarningType() {
        return transactionEarningType;
    }

    /**
     * Sets the value of the transactionEarningType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionEarningType }
     *     
     */
    public void setTransactionEarningType(TransactionEarningType value) {
        this.transactionEarningType = value;
    }

}
