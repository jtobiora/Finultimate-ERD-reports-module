
package com.s3systems.remote.sales;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for transactionEarningType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="transactionEarningType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NONE"/>
 *     &lt;enumeration value="ONE_OFF_EARNING"/>
 *     &lt;enumeration value="AMORTIZED_ADVANCE_EARNING"/>
 *     &lt;enumeration value="AMORTIZED_ARREARS_EARNING"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "transactionEarningType")
@XmlEnum
public enum TransactionEarningType {

    NONE,
    ONE_OFF_EARNING,
    AMORTIZED_ADVANCE_EARNING,
    AMORTIZED_ARREARS_EARNING;

    public String value() {
        return name();
    }

    public static TransactionEarningType fromValue(String v) {
        return valueOf(v);
    }

}
